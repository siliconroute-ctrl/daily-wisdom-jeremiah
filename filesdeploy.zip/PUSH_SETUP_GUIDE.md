# Push Notifications — Setup Guide

Everything is built. You do 3 things: get one key, place 2 files, run 2 commands.

---

## PART A — Frontend (5 minutes)

### 1. Get your Web Push key (VAPID key)
1. Go to: https://console.firebase.google.com
2. Select: daily-wisdom-jeremiah
3. Gear icon > Project Settings > "Cloud Messaging" tab
4. Scroll to "Web Push certificates"
5. Click "Generate key pair"
6. Copy the long key that appears (starts with "B...")

### 2. Paste the key into App.jsx
1. Open: src\App.jsx (the NEW version from this package)
2. Near the top, find this line:
   const VAPID_KEY = 'PASTE_YOUR_VAPID_KEY_HERE';
3. Replace PASTE_YOUR_VAPID_KEY_HERE with your copied key (keep the quotes)
4. Save

### 3. Add the service worker
1. In your project folder, find (or create) a folder called: public
   Full path: C:\Users\joao\Documents\daily-wisdom-jeremiah\public
2. Put firebase-messaging-sw.js (from this package) inside it

### 4. Deploy the frontend
    git add .
    git commit -m "Add push notifications and privacy policy"
    git push

Vercel deploys automatically.

---

## PART B — The daily sender (10 minutes, one-time)

### 5. Upgrade Firebase to Blaze plan (required for scheduled functions)
1. Firebase Console > bottom-left "Spark plan" > Upgrade > Blaze
2. Add a payment card
- Don't worry: one function running once a day costs R0-R2 per month.
  You can set a budget alert of $1 during upgrade to be safe.

### 6. Add the function files
1. In your project folder, create a folder called: functions
   Full path: C:\Users\joao\Documents\daily-wisdom-jeremiah\functions
2. Put these 2 files (from this package) inside it:
   - index.js
   - package.json

### 7. Deploy the function
In Command Prompt:

    cd C:\Users\joao\Documents\daily-wisdom-jeremiah\functions
    npm install
    cd ..
    firebase deploy --only functions

Wait 2-4 minutes. Success looks like:
    Deploy complete!
    Function URL / dailyVersePush(europe-west1)

---

## TESTING

1. Open your live app on your phone (Chrome on Android works best)
2. Settings > switch "Daily notifications" ON
3. Allow the permission popup
4. You should see: "Notifications enabled on this device."
5. Tomorrow at 07:00 the verse arrives automatically.

To test immediately without waiting for 07:00:
Firebase Console > Functions > dailyVersePush > 3-dot menu > "Test function"
(or temporarily change the schedule to a few minutes ahead and redeploy)

---

## NOTES

- iPhone: web push works only if the user adds the app to their
  Home Screen first (Share button > Add to Home Screen). Android: works directly.
- POPIA: notifications are opt-in (off by default), one-tap opt-out in
  Settings, and the privacy policy is linked in Settings and on the
  sign-in page. Device tokens are removed when a user opts out.
- Cost: FCM push is free at any scale. The scheduled function costs
  effectively zero at your usage.
